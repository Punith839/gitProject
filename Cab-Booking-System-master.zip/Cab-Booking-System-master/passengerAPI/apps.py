from django.apps import AppConfig


class PassengerapiConfig(AppConfig):
    name = 'passengerAPI'
