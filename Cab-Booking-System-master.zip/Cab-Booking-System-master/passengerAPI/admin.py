from django.contrib import admin
from .models import Passenger, TravelHistory
# Register your models here.

admin.site.register(Passenger)
admin.site.register(TravelHistory)
# admin.site.register(RequestedCab)
