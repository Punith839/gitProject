from django.apps import AppConfig


class DriverapiConfig(AppConfig):
    name = 'driverAPI'
