from django.apps import AppConfig


class FruitsConfig(AppConfig):
    name = 'fruits'
