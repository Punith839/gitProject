from django.apps import AppConfig


class VegetablesConfig(AppConfig):
    name = 'vegetables'
