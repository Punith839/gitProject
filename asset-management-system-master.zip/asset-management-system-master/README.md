# asset-management-system
This is a Python web application based on Django Framework that allows a company admin to see which employee has which assets by keeping track of the assets vital to day-to-day operation of their businesses. This application uses Pusher to send the admin notifications on user activities such as login, logout and profile update.
