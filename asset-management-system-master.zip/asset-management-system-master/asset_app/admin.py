from django.contrib import admin
from .models import Assets

admin.site.register(Assets)
