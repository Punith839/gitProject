from django.apps import AppConfig


class AssetAppConfig(AppConfig):
    name = 'asset_app'
